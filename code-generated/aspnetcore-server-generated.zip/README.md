# IO.Swagger - ASP.NET Core 2.0 Server

CommonMarks   # Heading 1 ## Heading 2 ### Heading 3 #### Heading 4 ##### Heading 5 ###### Heading 6 (Max)  - Bullet 1   - Sub-bullet     - Sub-sub bullet       - Sub-sub-sub-bullet - Bullet 2   **Bold** *Italic* ***BoldItalic***  This is a summarry explaining what the API is about.  [Link text](www.google.com)  Image:  ![Alt text](https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png)  ```word highlight```  Python code: ```python def hello_world():   print(\"Hello, world!\") ``` test ```xml <tag></tag> ``` 

## Run

Linux/OS X:

```
sh build.sh
```

Windows:

```
build.bat
```

## Run in Docker

```
cd src/IO.Swagger
docker build -t io.swagger .
docker run -p 5000:5000 io.swagger
```
