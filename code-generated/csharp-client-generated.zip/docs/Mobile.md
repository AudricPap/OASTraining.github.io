# IO.Swagger.Model.Mobile
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ProductId** | **int?** |  | [optional] 
**ProductName** | **string** |  | [optional] 
**ProductPrice** | **float?** |  | [optional] 
**CategoryId** | **int?** |  | [optional] 
**CategoryName** | **string** |  | [optional] 
**ReleaseDate** | **DateTime?** |  | [optional] 
**StockQuantity** | **int?** |  | [optional] 
**NetworkType** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

