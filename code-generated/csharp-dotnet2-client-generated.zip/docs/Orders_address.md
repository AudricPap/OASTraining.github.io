# IO.Swagger.Model.OrdersAddress
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address1** | **string** |  | [optional] 
**AddressCity** | **string** |  | [optional] 
**AddressState** | **string** |  | [optional] 
**AddressZipCode** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

