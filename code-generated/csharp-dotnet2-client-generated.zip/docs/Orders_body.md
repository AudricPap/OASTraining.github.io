# IO.Swagger.Model.OrdersBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Products** | [**List&lt;Product&gt;**](Product.md) |  | [optional] 
**Address** | [**Address**](Address.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

