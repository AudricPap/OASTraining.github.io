# IO.Swagger.Model.OrderSummary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Products** | [**List&lt;Product&gt;**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

