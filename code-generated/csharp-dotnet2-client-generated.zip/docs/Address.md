# IO.Swagger.Model.Address
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address1** | **string** |  | 
**AddressCity** | **string** |  | 
**AddressState** | **string** |  | 
**AddressZipCode** | **string** |  | 
**AdressIsOffice** | **bool?** |  | [optional] [default to false]
**AdressType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

