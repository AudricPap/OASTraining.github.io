# IO.Swagger.Model.InlineResponse200
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OrderId** | **int?** |  | [optional] 
**Address** | [**OrdersAddress**](OrdersAddress.md) |  | [optional] 
**Products** | [**List&lt;OrdersProducts&gt;**](OrdersProducts.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

