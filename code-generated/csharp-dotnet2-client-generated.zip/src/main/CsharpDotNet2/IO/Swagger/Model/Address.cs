using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Address {
    /// <summary>
    /// Gets or Sets Address1
    /// </summary>
    [DataMember(Name="address1", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "address1")]
    public string Address1 { get; set; }

    /// <summary>
    /// Gets or Sets AddressCity
    /// </summary>
    [DataMember(Name="addressCity", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "addressCity")]
    public string AddressCity { get; set; }

    /// <summary>
    /// Gets or Sets AddressState
    /// </summary>
    [DataMember(Name="addressState", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "addressState")]
    public string AddressState { get; set; }

    /// <summary>
    /// Gets or Sets AddressZipCode
    /// </summary>
    [DataMember(Name="addressZipCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "addressZipCode")]
    public string AddressZipCode { get; set; }

    /// <summary>
    /// Gets or Sets AdressIsOffice
    /// </summary>
    [DataMember(Name="adressIsOffice", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "adressIsOffice")]
    public bool? AdressIsOffice { get; set; }

    /// <summary>
    /// Gets or Sets AdressType
    /// </summary>
    [DataMember(Name="adressType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "adressType")]
    public string AdressType { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Address {\n");
      sb.Append("  Address1: ").Append(Address1).Append("\n");
      sb.Append("  AddressCity: ").Append(AddressCity).Append("\n");
      sb.Append("  AddressState: ").Append(AddressState).Append("\n");
      sb.Append("  AddressZipCode: ").Append(AddressZipCode).Append("\n");
      sb.Append("  AdressIsOffice: ").Append(AdressIsOffice).Append("\n");
      sb.Append("  AdressType: ").Append(AdressType).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
