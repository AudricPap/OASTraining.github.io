using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductsApi
    {
        /// <summary>
        /// Get all products Return all products in EazyShop catalog
        /// </summary>
        /// <param name="categoryId"></param>
        /// <returns>List&lt;Product&gt;</returns>
        List<Product> GetProducts (int? categoryId);
        /// <summary>
        /// Get a product Return a specific product in EazyShop catalog
        /// </summary>
        /// <param name="productId"></param>
        /// <returns>Product</returns>
        Product GetProductsById (int? productId);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductsApi : IProductsApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductsApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductsApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductsApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductsApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Get all products Return all products in EazyShop catalog
        /// </summary>
        /// <param name="categoryId"></param>
        /// <returns>List&lt;Product&gt;</returns>
        public List<Product> GetProducts (int? categoryId)
        {
    
            var path = "/products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (categoryId != null) queryParams.Add("categoryId", ApiClient.ParameterToString(categoryId)); // query parameter
                        
            // authentication setting, if any
            String[] authSettings = new String[] { "ApiKeyAuth", "BasicAuth", "BearerAuth", "OAuth2AuthCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetProducts: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetProducts: " + response.ErrorMessage, response.ErrorMessage);
    
            return (List<Product>) ApiClient.Deserialize(response.Content, typeof(List<Product>), response.Headers);
        }
    
        /// <summary>
        /// Get a product Return a specific product in EazyShop catalog
        /// </summary>
        /// <param name="productId"></param>
        /// <returns>Product</returns>
        public Product GetProductsById (int? productId)
        {
            // verify the required parameter 'productId' is set
            if (productId == null) throw new ApiException(400, "Missing required parameter 'productId' when calling GetProductsById");
    
            var path = "/products/{productId}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "productId" + "}", ApiClient.ParameterToString(productId));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "ApiKeyAuth", "BasicAuth", "BearerAuth", "OAuth2AuthCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetProductsById: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetProductsById: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Product) ApiClient.Deserialize(response.Content, typeof(Product), response.Headers);
        }
    
    }
}
