using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IOrdersApi
    {
        /// <summary>
        /// Get Order Details Get Order Details base don Order ID
        /// </summary>
        /// <param name="orderId"></param>
        /// <param name="fetchType">Fetch Type:  * &#x60;summary&#x60; - Will provide Order Summary  * &#x60;details&#x60; - Will provide Order Summary &amp; Order Address </param>
        /// <returns>InlineResponse2001</returns>
        InlineResponse2001 AnyofOrderGet (int? orderId, string fetchType);
        /// <summary>
        /// Delete an order Delete an order
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        void DeleteOrder (int? orderId);
        /// <summary>
        /// Get orders Return all orders for the logged-in customer
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns>List&lt;InlineResponse200&gt;</returns>
        List<InlineResponse200> GetOrders (int? orderId);
        /// <summary>
        /// Insert OneOf the Order Details Insert OneOf the Order details into EazyShop
        /// </summary>
        /// <param name="body"></param>
        /// <returns></returns>
        void OneOfOrderPost (OneOfOrderBody body);
        /// <summary>
        /// Get an order by id Return an order
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns>Product</returns>
        Product OrdersOrderIdGet (int? orderId);
        /// <summary>
        /// Put an order Update an order
        /// </summary>
        /// <param name="body"></param>
        /// <returns>Order</returns>
        Order UpdateOrder (OrdersBody body);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class OrdersApi : IOrdersApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OrdersApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public OrdersApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="OrdersApi"/> class.
        /// </summary>
        /// <returns></returns>
        public OrdersApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Get Order Details Get Order Details base don Order ID
        /// </summary>
        /// <param name="orderId"></param>
        /// <param name="fetchType">Fetch Type:  * &#x60;summary&#x60; - Will provide Order Summary  * &#x60;details&#x60; - Will provide Order Summary &amp; Order Address </param>
        /// <returns>InlineResponse2001</returns>
        public InlineResponse2001 AnyofOrderGet (int? orderId, string fetchType)
        {
            // verify the required parameter 'orderId' is set
            if (orderId == null) throw new ApiException(400, "Missing required parameter 'orderId' when calling AnyofOrderGet");
            // verify the required parameter 'fetchType' is set
            if (fetchType == null) throw new ApiException(400, "Missing required parameter 'fetchType' when calling AnyofOrderGet");
    
            var path = "/anyofOrder";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (orderId != null) queryParams.Add("orderId", ApiClient.ParameterToString(orderId)); // query parameter
 if (fetchType != null) queryParams.Add("fetchType", ApiClient.ParameterToString(fetchType)); // query parameter
                        
            // authentication setting, if any
            String[] authSettings = new String[] { "ApiKeyAuth", "BasicAuth", "BearerAuth", "OAuth2AuthCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling AnyofOrderGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling AnyofOrderGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2001) ApiClient.Deserialize(response.Content, typeof(InlineResponse2001), response.Headers);
        }
    
        /// <summary>
        /// Delete an order Delete an order
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        public void DeleteOrder (int? orderId)
        {
            // verify the required parameter 'orderId' is set
            if (orderId == null) throw new ApiException(400, "Missing required parameter 'orderId' when calling DeleteOrder");
    
            var path = "/orders";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (orderId != null) queryParams.Add("orderId", ApiClient.ParameterToString(orderId)); // query parameter
                        
            // authentication setting, if any
            String[] authSettings = new String[] { "ApiKeyAuth", "BasicAuth", "BearerAuth", "OAuth2AuthCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteOrder: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteOrder: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Get orders Return all orders for the logged-in customer
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns>List&lt;InlineResponse200&gt;</returns>
        public List<InlineResponse200> GetOrders (int? orderId)
        {
            // verify the required parameter 'orderId' is set
            if (orderId == null) throw new ApiException(400, "Missing required parameter 'orderId' when calling GetOrders");
    
            var path = "/orders";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (orderId != null) queryParams.Add("orderId", ApiClient.ParameterToString(orderId)); // query parameter
                        
            // authentication setting, if any
            String[] authSettings = new String[] { "ApiKeyAuth", "BasicAuth", "BearerAuth", "OAuth2AuthCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOrders: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOrders: " + response.ErrorMessage, response.ErrorMessage);
    
            return (List<InlineResponse200>) ApiClient.Deserialize(response.Content, typeof(List<InlineResponse200>), response.Headers);
        }
    
        /// <summary>
        /// Insert OneOf the Order Details Insert OneOf the Order details into EazyShop
        /// </summary>
        /// <param name="body"></param>
        /// <returns></returns>
        public void OneOfOrderPost (OneOfOrderBody body)
        {
    
            var path = "/oneOfOrder";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                    postBody = ApiClient.Serialize(body); // http body (model) parameter

            // authentication setting, if any
            String[] authSettings = new String[] { "ApiKeyAuth", "BasicAuth", "BearerAuth", "OAuth2AuthCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OneOfOrderPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OneOfOrderPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Get an order by id Return an order
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns>Product</returns>
        public Product OrdersOrderIdGet (int? orderId)
        {
            // verify the required parameter 'orderId' is set
            if (orderId == null) throw new ApiException(400, "Missing required parameter 'orderId' when calling OrdersOrderIdGet");
    
            var path = "/orders/{orderId}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "orderId" + "}", ApiClient.ParameterToString(orderId));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "ApiKeyAuth", "BasicAuth", "BearerAuth", "OAuth2AuthCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrdersOrderIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrdersOrderIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Product) ApiClient.Deserialize(response.Content, typeof(Product), response.Headers);
        }
    
        /// <summary>
        /// Put an order Update an order
        /// </summary>
        /// <param name="body"></param>
        /// <returns>Order</returns>
        public Order UpdateOrder (OrdersBody body)
        {
    
            var path = "/orders";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                    postBody = ApiClient.Serialize(body); // http body (model) parameter

            // authentication setting, if any
            String[] authSettings = new String[] { "ApiKeyAuth", "BasicAuth", "BearerAuth", "OAuth2AuthCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling UpdateOrder: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling UpdateOrder: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Order) ApiClient.Deserialize(response.Content, typeof(Order), response.Headers);
        }
    
    }
}
